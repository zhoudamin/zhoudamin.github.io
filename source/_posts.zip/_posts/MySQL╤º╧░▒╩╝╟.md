---
title: MySQL学习笔记
字数统计: WordCount
阅读时长预计: Min2Read
总字数统计: TotalCount
date: 2017-03-16 21:40:15
categories: 数据库
tags: MySQL
---

关于MySQL学习过程中的一些总结！
<!--more-->

![](http://pic.sc.chinaz.com/files/pic/pic9/201508/apic14250.jpg)
# 基础知识
MySQL默认的端口号是3306；
MySQL中的超级用户叫 root；
创建数据库： create database ；
修改数据库： alter database ；
删除数据库： drop database ；

登陆MySQL客户端 : mysql -uroot -p16213018 -P3306 -h127.0.0.1

查看数据库 ： SHOW DATABASES；

打开test数据库 :　USE test ;

创建数据表： CREATE TABLE tb1(
            username VARCHAR(20),
            age TINYINT UNSIGNED,
            salary FLOAT(8,2) UNSIGNED 
            );

查看数据表： SHOW TABLES ；

查看数据表结构： SHOW COLUMNS FROM tb1 ;       

插入记录： 	INSERT tb1 VALUES('Tom',25,6843.34);

记录查找： SELECT * FROM tb1;
 	     
空值与非空：
CREATE TABLE(20) tb2(
username VARCHAR(20) NOT NULL,
age TINYINT UNSIGNED NULL
);


查表： SHOW COLUMNS tb2;


# 创建用户表以及问题表
如果存在则先删除再创建
```
DROP TABLE IF EXISTS `question`;
CREATE TABLE `question` (
`id` INT NOT NULL AUTO_INCREMENT,
`title` VARCHAR(255) NOT NULL,
`content` TEXT NULL,
`user_id` INT NOT NULL,
`created_date` DATETIME NOT NULL,
`comment_count` INT NOT NULL,
PRIMARY KEY (`id`),
INDEX `date_index` (`created_date` ASC));

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(64) NOT NULL DEFAULT ‘’,
  `password` VARCHAR(128) NOT NULL DEFAULT ‘’ ,
  ‘salt’ VARCHAR(32)  NOT NULL DEFAULT ‘’ ,
  ‘head_url’ VARCHAR(256)  NOT NULL DEFAULT ‘’  ,
  PRIMARY KEY (`id`)
  UNIQUE KEY ‘name’ (‘name’)
) ENGINE=INNODB  DEFAULT CHARSET=utf8
```
# 查询表格
```
SELECT * FROM  question;
```

## 删除数据库cache
```
 DROP DATABASE CACHE;
```
## 创建数据库cache
```
CREATE DATABASE CACHE;  // 创建一个数据库
```

## 创建表格
```
CREATE TABLE SYS_ROLE(
  ID INTEGER,
  NAME VARCHAR(255) NOT NULL
);

CREATE TABLE SYS_ROLE_USER(
  SYS_USER_ID INTEGER,
  ROLES_ID INTEGER
);



INSERT INTO SYS_ROLE(id,NAME) VALUES(1,'ROLE_ADMIN');
INSERT INTO SYS_ROLE(id,NAME) VALUES(2,'ROLE_USER');

INSERT INTO SYS_ROLE_USER(SYS_USER_ID,ROLES_ID) VALUES(1,1);
INSERT INTO SYS_ROLE_USER(SYS_USER_ID,ROLES_ID) VALUES(2,2);
```


```
DROP TABLE IF EXISTS  `city`;
CREATE TABLE `city` (
  `id` INT(10) UNSIGNED NOT NULL ,
  `province_id` INT(10) UNSIGNED  NOT NULL ,
  `city_name` VARCHAR(25) DEFAULT NULL ,
  `description` VARCHAR(25) DEFAULT NULL ,
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


INSERT INTO city(id,province_id,city_name,description) VALUES(2 ,2,'长沙','我家在长沙');
```


```
CREATE DATABASE Persion; 

CREATE TABLE `persion` (
  `id` INT(10) UNSIGNED NOT NULL ,
  `persion_id` INT(10) UNSIGNED  NOT NULL ,
  `persion_name` VARCHAR(25) DEFAULT NULL ,
  `description` VARCHAR(25) DEFAULT NULL ,
  PRIMARY KEY (`id`)
) ENGINE=INNODB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


```


![](http://img.hb.aicdn.com/4dcce664f96139dec4da41fdf0db4348b48cc1a956b64-EyQA8R_fw658)