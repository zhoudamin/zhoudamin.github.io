---
title: 常考面试算法题之DFS/BFS
字数统计: WordCount
阅读时长预计: Min2Read
总字数统计: TotalCount
date: 2017-07-22 16:56:06
categories: 算法
tags:
- 面试
- Java
- 笔试
- 算法
---

![](https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1381141477,4106246935&fm=11&gp=0.jpg)
<!--more-->
推箱子

工作安排

幸运的袋子

饥饿的小易

跳石板

地下迷宫

```
Java代码实现
```
<br/>

![](http://img0.pconline.com.cn/pconline/1104/26/2398938_cab-window-615.gif)