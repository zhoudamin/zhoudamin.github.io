---
title: JS Notes
字数统计: WordCount
阅读时长预计: Min2Read
总字数统计: TotalCount
date: 2017-05-20 11:14:42
categories: Java
tags: JS
---

项目需求，初学JS Notes。
![](http://cdn01.wallconvert.com/_media/wp_400x250/1/5/41579.jpg)
<!--more-->
``
1.基础
``
常用函数
```
alert("提示框");
document.write("输出内容");
```

定义变量
```
var 变量名=值;
```

内置对象
```
String 对象
Number 对象
Boolean 对象
Math 对象
Date 对象
Array 对象
```

自定义对象
```
Java：用class 来定义对象
JS：用 function 来定义对象
```


![](http://cdn01.wallconvert.com/_media/wp_400x250/1/5/40344.jpg)